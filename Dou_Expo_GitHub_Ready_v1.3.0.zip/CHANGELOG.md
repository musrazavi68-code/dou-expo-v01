# Changelog

## 1.3.0 — Finalization pass

- Replaced the single local settings snapshot with a multi-project IndexedDB library.
- Saved projects now include the editor/export settings and local PNG copies of both selected source images.
- Added create, open, update, delete and blank-project actions.
- Added explicit success/failure feedback from the Android MediaStore export bridge to the web editor.
- Persisted document-provider read permission when supported, improving image reopen behavior.
- Added Android system-bar and display-cutout inset handling for edge-to-edge Android 15+ devices.
- Added optional release APK signing through GitHub Actions secrets and automatic GitHub Release publishing for `v*` tags.
- Updated validation to check project-library hooks and all five pattern categories (10 patterns each).

## 1.2.0

- Added 50 original SVG patterns in five curated categories.
- Added search, filters, live pattern selection and opacity control.
