# Dou Expo Pattern Library — sourcing & license notes

The 50-pattern collection in `app/src/main/assets/patterns/` is original editable SVG artwork created for this project. It is curated using visual principles (figure–ground separation, repetition/rhythm, proximity, closure, continuity and negative space), with five categories: brush marks, botanical/autumn leaves, silhouettes, textured frames, and gestalt/abstract motifs.

External inspiration and reusable public-domain source pools reviewed:

- [FreeSVG.org](https://freesvg.org/) — its site states that its SVG library is Creative Commons Zero / public domain and permits copying, modification, distribution and commercial use. Individual asset pages should still be checked before importing any third-party file.
- [Patterns for Paintbrush imitation #01](https://freesvg.org/patterns-for-paintbrush-imitation-01) — dry-brush path treatment, marked Public Domain on its asset page.
- [Autumn Leaves Silhouettes](https://freesvg.org/1539124050) — botanical silhouette reference, marked Public Domain on its asset page.
- [Autumn Leaves seamless texture](https://freesvg.org/autumnleaves) — public-domain seasonal texture reference.
- [Plotcaster distressed SVG textures](https://www.plotcaster.com/svg/distressed/) — useful reference for distressed overlays, speckle, scratches, grunge and paint splatter; page states free for personal and commercial use.

No third-party SVG is bundled as if it were our own. The in-app 50 tiles are original SVGs generated for Dou Expo; external links are documented as inspiration/source pools, not as claims that their files were downloaded or redistributed. Verify the license on the individual asset page before adding further third-party assets.
