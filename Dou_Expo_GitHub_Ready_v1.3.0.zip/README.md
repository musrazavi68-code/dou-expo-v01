# Dou Expo Studio — Android

A responsive Android photo-composition app built with a native Android WebView shell (AndroidX WebViewAssetLoader on a secure local HTTPS origin) and a local HTML Canvas editor. The project is arranged as a GitHub repository root and includes an editable vector design board for Figma import.

## Current version

- App version: **1.3.0** (versionCode 4)
- Android: minSdk 23 (Android 6.0), compileSdk/targetSdk 35
- Java: 17
- Gradle: 8.9 (GitHub Actions)

## Features included

- Launch screen and adaptive editor navigation.
- Base image + overlay image import (JPG, PNG, WebP; 25 MB per image limit).
- Double-exposure blend modes: Screen, Multiply, Overlay, Soft Light, Lighten and Darken.
- Overlay scale, rotation, opacity and soft masks (linear, radial, diagonal and split).
- FX Lab: Aurora, Halftone, Chromatic, Film Grain, Light Leak, Bokeh, Vignette, Duotone, Emboss, Scanlines and Dream Glow.
- Color Lab: brightness, contrast, saturation and warmth.
- Pattern Studio: 50 curated, original SVG vector patterns in five groups (brush marks, botanical/autumn leaves, silhouettes, textured frames, and Gestalt/abstract). Search, category filters, live selection and opacity control; vector assets remain editable. See `PATTERN_SOURCES.md` for reviewed public-domain source pools and licensing notes.
- Export as PNG or JPEG at 1200, 1800 or 2400 px, with optional embedded Dou Expo watermark and adjustable opacity/position.
- Multi-project local library backed by IndexedDB. Each project stores editor/export settings and local PNG copies of selected source images, so the composition can be reopened on the same device.
- Responsive layout for narrow phones, landscape phones, foldables and tablets/iPad-sized screens; safe-area padding and adaptive inspector layout.
- Android image picker and MediaStore export to `Pictures/DouExpo`.

## Repository structure

```text
.
├── app/                         # Android application module
│   └── src/main/
│       ├── assets/               # Local editor, app icon and watermark
│       ├── java/                 # Native Android WebView bridge
│       └── res/                  # Android launcher icons
├── design_assets/
│   ├── Dou_Expo_Figma_Import.svg # Editable vector board for Figma
│   └── graphics-kit/             # Supplied master icon, splash, watermark, platform icons
├── .github/workflows/            # CI build workflow
├── scripts/                      # Source validation
├── Dou_Expo_Penpot_MVP.svg       # Earlier editable concept board
└── settings.gradle
```

## Build on GitHub

1. Create a repository (for example `dou-expo`).
2. Upload the **contents of this folder** to the repository root; do not upload the parent ZIP as a nested folder.
3. Push to the `main` branch.
4. Open **Actions → Build Dou Expo Android**.
5. Download the `DouExpo-Android-*` artifact from the successful run. It contains:
   - `app-debug.apk` — installable debug build for device testing.
   - `app-release-unsigned.apk` — release build, not signed for distribution.
   - `SHA256SUMS.txt` — checksums for both APKs.

The workflow runs the web-editor validation, Android unit-test task, Android lint and both APK builds. A distributable signed release requires a private signing keystore configured through GitHub Actions secrets. Add `DOU_EXPO_KEYSTORE_BASE64`, `DOU_EXPO_STORE_PASSWORD`, `DOU_EXPO_KEY_ALIAS`, and `DOU_EXPO_KEY_PASSWORD` under **Settings → Secrets and variables → Actions**. Without all four secrets, CI produces an unsigned release APK. Push a tag such as `v1.3.0` to create a GitHub Release containing the APK files and checksums. No signing credentials are included in this repository.

## Build locally

Requirements: JDK 17, Android SDK Platform 35, Android Build Tools, and Gradle 8.9.

```bash
python scripts/validate_web_assets.py
gradle testDebugUnitTest lintDebug assembleDebug
```

Debug APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Import the design into Figma

The editable vector board is `Dou_Expo_Figma_Import.svg` (five mobile screens plus the 50-pattern contact sheet and design tokens). It can be imported into Figma as SVG and ungrouped; individual pattern SVGs are also supplied separately.

1. Open the Figma file linked in the project handoff.
2. Drag the SVG onto a Design page, or use **File → Place image** and select the SVG.
3. Ungroup imported elements to edit screen layouts, labels, cards, controls and design tokens individually.
4. Use the supplied PNG/SVG files in `design_assets/graphics-kit/` for final app-icon, splash and watermark assets.

A Figma design file was created at the handoff stage. Direct insertion into that cloud file is currently blocked by the Figma Starter-plan MCP call limit; the full updated UI board is therefore supplied as an editable Figma-importable SVG source. Import the SVG into the file and ungroup to edit its vector elements.

## Project storage

Project records use IndexedDB (`douexpo-projects-v1`) and include source images as PNG blobs. The Projects screen supports creating, opening, updating, deleting and starting a blank project. Project images/settings are local to this installation and are not cloud-synced. See `app/src/main/assets/PROJECTS_HELP.md` for storage behavior and limitations.

## Export watermark

The watermark uses the supplied transparent graphic and reads:

- `Created by dou expo app`
- `Developed by M.Razavi`

Default placement is bottom-right; users can change position and opacity in the Export section.

## Known limitations / honest scope

- FX and patterns are original Canvas-based approximations, not native Alembic.space effects, licensed Alembic assets, or GPU/GLSL shaders. No Alembic account/API integration is included.
- The pattern gallery is now a curated 50-pattern original SVG collection. It does not redistribute third-party assets; external source references and licensing notes are documented in `PATTERN_SOURCES.md`.
- Projects are stored locally in IndexedDB with PNG copies of source images. They are not cloud-synced and may be removed if app data is cleared or the app is uninstalled.
- The app has not yet been device-tested across every foldable/tablet model. Responsive CSS and Android system-bar/cutout insets are included, but physical-device QA remains necessary.
- The repository has CI build instructions, but an APK has not been built in this local environment because Android SDK/Gradle are not installed here. The first GitHub Actions run is the authoritative build check.

## Privacy

Photos are selected through Android's system document picker and processed locally in the app. The app does not upload photos to a server. Saved project images and settings remain in local app/WebView storage on the device.
