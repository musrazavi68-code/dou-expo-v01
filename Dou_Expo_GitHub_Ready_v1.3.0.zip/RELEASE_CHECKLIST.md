# Dou Expo 1.3.0 release checklist

## Included and validated in source

- [x] Android WebView shell and local Canvas editor
- [x] Base/overlay image selection, six blend modes and masks
- [x] FX Lab and Color Lab controls
- [x] 50 original SVG patterns, five categories, 10 each
- [x] PNG/JPEG export at 1200/1800/2400 output widths
- [x] Optional Dou Expo watermark and placement/opacity controls
- [x] Multi-project IndexedDB library with source-image blobs
- [x] Native MediaStore export result callback
- [x] Android system bar/cutout insets
- [x] Figma-importable vector board and graphics kit
- [x] GitHub Actions build, lint, unit-test task, checksums and artifact upload
- [x] Optional signed APK and tag-based GitHub Release workflow

## Required after pushing to the user's GitHub repository

- [ ] Run **Actions → Build Dou Expo Android** and confirm green status.
- [ ] Install the debug APK on a physical Android phone; verify image selection, save/open projects, export, watermark and back navigation.
- [ ] Test narrow phone, landscape, foldable cover/open display and tablet layouts.
- [ ] If publishing a signed release, configure the four `DOU_EXPO_*` Actions secrets and push a `v1.3.0` tag.
- [ ] Import `Dou_Expo_Figma_Import.svg` into the cloud Figma file and ungroup it; direct Figma MCP insertion was blocked by the Starter plan call limit in this session.

## Release caveats

- Projects are local to the app/WebView installation and are not cloud-synced.
- No Alembic.space API integration or licensed Alembic assets are bundled; FX are local Canvas implementations.
- A green CI build does not replace physical-device QA.
