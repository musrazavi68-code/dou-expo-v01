Dou Expo local project storage
==============================

- Project records are stored in IndexedDB database `douexpo-projects-v1`.
- Each record contains the complete set of editor controls, export preferences, selected pattern/effect, and PNG copies of the selected base/overlay images.
- Projects remain on the current device/browser profile. They are not cloud-synced and are removed if the app's storage is cleared or the app is uninstalled.
- Large source images can use significant device storage. A failed save reports the storage error rather than silently claiming success.
- Exported artwork is separate and is written to Pictures/DouExpo by the Android MediaStore bridge.
