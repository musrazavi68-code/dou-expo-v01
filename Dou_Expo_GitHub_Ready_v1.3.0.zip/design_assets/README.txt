Dou Expo visual assets
- dou_expo_icon_transparent.png: transparent PNG converted from the user-provided app icon.
- splash_screen_preview.png: vertical visual reference for the launcher/splash screen.
The actual app launch screen uses the transparent icon and HTML/CSS layout in app/src/main/assets/index.html.
