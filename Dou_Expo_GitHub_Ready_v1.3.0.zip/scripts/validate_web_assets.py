from html.parser import HTMLParser
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import json
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
HTML = ROOT / "app/src/main/assets/index.html"
ASSETS = ROOT / "app/src/main/assets"

class IdParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids = []
    def handle_starttag(self, tag, attrs):
        for key, value in attrs:
            if key == "id" and value:
                self.ids.append(value)

source = HTML.read_text(encoding="utf-8")
parser = IdParser()
parser.feed(source)
duplicates = sorted({x for x in parser.ids if parser.ids.count(x) > 1})
if duplicates:
    raise SystemExit(f"Duplicate HTML IDs: {duplicates}")

required_assets = ["dou_expo_icon.png", "dou_expo_watermark.png"]
missing = [name for name in required_assets if not (ASSETS / name).is_file()]
if missing:
    raise SystemExit(f"Missing app assets: {missing}")

scripts = re.findall(r"<script>(.*?)</script>", source, flags=re.S)
if len(scripts) != 1:
    raise SystemExit(f"Expected one inline app script, found {len(scripts)}")
node = shutil.which("node")
if not node:
    print("SKIP: Node.js not installed; HTML and asset checks passed")
else:
    with tempfile.NamedTemporaryFile("w", suffix=".js", encoding="utf-8", delete=False) as tmp:
        tmp.write(scripts[0])
        temp_path = tmp.name
    try:
        subprocess.run([node, "--check", temp_path], check=True)
    finally:
        Path(temp_path).unlink(missing_ok=True)
    print("PASS: inline JavaScript syntax")

pattern_dir = ASSETS / "patterns"
manifest_path = pattern_dir / "patterns.json"
manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
patterns = manifest.get("patterns", [])
if manifest.get("count") != 50 or len(patterns) != 50:
    raise SystemExit(f"Pattern manifest must contain exactly 50 patterns; found {len(patterns)}")
missing_patterns = [p["file"] for p in patterns if not (ASSETS / p["file"]).is_file()]
if missing_patterns:
    raise SystemExit(f"Missing pattern SVG assets: {missing_patterns}")
category_counts = {}
for item in patterns:
    ET.parse(ASSETS / item["file"])
    category_counts[item["category"]] = category_counts.get(item["category"], 0) + 1
if sorted(category_counts.values()) != [10, 10, 10, 10, 10]:
    raise SystemExit(f"Expected 10 patterns in each of five categories; found {category_counts}")
ET.parse(ROOT / "Dou_Expo_Figma_Import.svg")
project_ui = ['projectName', 'projectSelect', 'saveProject()', 'updateProject()', 'loadProject()', 'deleteProject()', 'indexedDB.open']
missing_project_features = [feature for feature in project_ui if feature not in source]
if missing_project_features:
    raise SystemExit(f"Missing project-library feature markers: {missing_project_features}")
if 'onNativeSaveResult' not in source:
    raise SystemExit("Missing native export result callback")
java_source = (ROOT / "app/src/main/java/com/douexpo/app/MainActivity.java").read_text(encoding="utf-8")
for marker in ["WebViewAssetLoader", "https://appassets.androidplatform.net/assets/index.html", "takePersistableUriPermission", "MediaStore.Images.Media.RELATIVE_PATH"]:
    if marker not in java_source:
        raise SystemExit(f"Missing Android integration marker: {marker}")
if "androidx.webkit:webkit:1.12.1" not in (ROOT / "app/build.gradle").read_text(encoding="utf-8"):
    raise SystemExit("WebViewAssetLoader dependency is missing")
print("PASS: 50 pattern SVG assets (10 per category), manifest, and Figma import board are valid")
print("PASS: IndexedDB project library and native export result callback are present")
print(f"PASS: {len(parser.ids)} unique HTML IDs; required app assets present")
