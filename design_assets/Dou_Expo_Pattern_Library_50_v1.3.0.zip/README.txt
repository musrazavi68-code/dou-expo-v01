Dou Expo — Pattern Library v1.3.0
50 editable SVG patterns in five curated categories (10 each): brush marks, botanical/autumn leaves, silhouettes, textured frames, Gestalt/abstract.
All in-app SVGs are original Dou Expo vector artwork. External inspiration and license review notes are in PATTERN_SOURCES.md.
